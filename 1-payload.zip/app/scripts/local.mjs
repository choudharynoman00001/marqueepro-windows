// One-computer mode: runs a private PostgreSQL inside ./marqueepro-data and the MarqueePro server on this PC only.
// Works the same on Windows and Linux. Open http://localhost:3000 afterwards. Press Ctrl+C to stop.
import EmbeddedPostgres from 'embedded-postgres';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import pg from 'pg';

const root = process.cwd();
const data = path.resolve(process.env.MARQUEE_DATA || path.join(root, 'marqueepro-data'));
const dbDir = path.join(data, 'pg'); const pgPort = Number(process.env.PGPORT || 54329); const webPort = Number(process.env.PORT || 3000);
fs.mkdirSync(data, { recursive: true });
for (const f of ['dist/src/bootstrap.js', 'apps/web/dist/index.html']) if (!fs.existsSync(path.join(root, f))) { console.error(`Missing ${f}. Run: npm run build:api   and   npm run build:web`); process.exit(1); }

// The two database passwords are made once and kept in the data folder. They never leave this computer.
const secretFile = path.join(data, 'local-secrets.json');
if (!fs.existsSync(secretFile)) { const r = () => [...crypto.getRandomValues(new Uint8Array(24))].map((x) => 'abcdefghijkmnpqrstuvwxyz23456789'[x % 32]).join(''); fs.writeFileSync(secretFile, JSON.stringify({ admin: r(), app: r() })); }
const sec = JSON.parse(fs.readFileSync(secretFile, 'utf8'));

const server = new EmbeddedPostgres({ databaseDir: dbDir, user: 'postgres', password: sec.admin, port: pgPort, persistent: true, onLog: () => {}, onError: () => {} });
const fresh = !fs.existsSync(path.join(dbDir, 'PG_VERSION'));
if (fresh) await server.initialise();
await server.start();
const adminUrl = `postgresql://postgres:${sec.admin}@127.0.0.1:${pgPort}/marquee`;
if (fresh) await server.createDatabase('marquee');
const c = new pg.Client({ connectionString: adminUrl }); await c.connect();
const has = await c.query("SELECT 1 FROM pg_roles WHERE rolname='marquee_app'");
if (!has.rowCount) await c.query(`CREATE ROLE marquee_app LOGIN PASSWORD '${sec.app}' NOSUPERUSER NOBYPASSRLS`);
await c.end();
const prismaCli = createRequire(import.meta.url).resolve('prisma/build/index.js');
execFileSync(process.execPath, [prismaCli, 'migrate', 'deploy'], { cwd: root, env: { ...process.env, DATABASE_URL: adminUrl }, stdio: 'inherit' });

process.env.DATABASE_URL = `postgresql://marquee_app:${sec.app}@127.0.0.1:${pgPort}/marquee`;
process.env.DATA_DIR = data; process.env.BACKUP_DIR ||= path.join(data, 'backups');
const { createApp, ensureSuperAdmin } = await import(pathToUrl(path.join(root, 'dist/src/bootstrap.js')));
const { PrismaService } = await import(pathToUrl(path.join(root, 'dist/src/infra.js')));
const app = await createApp({ webDir: path.join(root, 'apps/web/dist') }); await ensureSuperAdmin(app.get(PrismaService));
await app.listen(webPort, '127.0.0.1');
console.log(`\nMarqueePro is running: http://localhost:${webPort}\nYour data folder: ${data}\nFirst start: the platform admin password is in ${path.join(data, 'bootstrap-admin.txt')}\nPress Ctrl+C to stop.`);
const stop = async () => { try { await app.close(); await server.stop(); } finally { process.exit(0); } };
process.on('SIGINT', stop); process.on('SIGTERM', stop);
function pathToUrl(p) { return new URL('file://' + (p.startsWith('/') ? '' : '/') + p.replace(/\\/g, '/')).href; }
