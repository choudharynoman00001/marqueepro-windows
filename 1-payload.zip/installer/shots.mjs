// Headless Edge screenshots of the INSTALLED app (page content only, not window chrome). Synthetic data only.
import puppeteer from 'puppeteer-core';
import fs from 'node:fs';
const st = JSON.parse(fs.readFileSync(process.env.RUNNER_TEMP + '\\smoke-state.json', 'utf8'));
const out = process.env.RUNNER_TEMP + '\\shots\\out'; fs.mkdirSync(out, { recursive: true });
const b = await puppeteer.launch({ executablePath: process.env.EDGE, headless: true, args: ['--no-sandbox'] });
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
async function fill(pg, vals) { const ins = await pg.$$('input'); for (let i = 0; i < vals.length; i++) await ins[i].type(vals[i]); await pg.keyboard.press('Enter'); await wait(2500); }
for (const [n, w, h] of [['desktop', 1280, 800], ['mobile', 390, 800]]) {
  let pg = await b.newPage(); await pg.setViewport({ width: w, height: h }); await pg.goto('http://localhost:3000/', { waitUntil: 'networkidle0' });
  await pg.screenshot({ path: `${out}\\win-${n}-1-login.png` });
  await fill(pg, [st.user, st.np]); await pg.screenshot({ path: `${out}\\win-${n}-2-admin-readback-businesses.png` }); await pg.close();
  pg = await b.newPage(); await pg.setViewport({ width: w, height: h }); await pg.goto('http://localhost:3000/', { waitUntil: 'networkidle0' });
  await fill(pg, [st.owner, st.ownerTemp]);
  const ins = await pg.$$('input'); if (ins.length >= 2) { await ins[0].type(st.ownerTemp); await ins[1].type('OwnerSmoke#4321xy'); await pg.keyboard.press('Enter'); await wait(3000); }
  await pg.screenshot({ path: `${out}\\win-${n}-3-owner-dashboard.png` }); await pg.close();
}
await b.close(); console.log('shots ok: ' + fs.readdirSync(out).join(','));
