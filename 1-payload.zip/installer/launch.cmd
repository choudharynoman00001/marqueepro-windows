@echo off
rem MarqueePro one-PC launcher. Data stays in %LOCALAPPDATA%\MarqueePro\data on this PC.
setlocal
set "APP=%~dp0..\app"
set "MARQUEE_DATA=%LOCALAPPDATA%\MarqueePro\data"
if "%PORT%"=="" set "PORT=3000"
cd /d "%APP%"
start "" "http://localhost:%PORT%"
"%~dp0..\runtime\node.exe" scripts\local.mjs
