# Silent install, start, health, login, password change, write, stop, restart, readback. Synthetic only.
$ErrorActionPreference='Stop'
$inst="$env:LOCALAPPDATA\Programs\MarqueePro"; $data="$env:LOCALAPPDATA\MarqueePro\data"
Start-Process -Wait -FilePath .\MarqueePro-Setup.exe -ArgumentList '/S'
if(-not (Test-Path "$inst\runtime\node.exe")){throw 'install missing'}
function Start-App{ $env:MARQUEE_DATA=$data; $env:PORT='3000'
  $p=Start-Process -PassThru -WindowStyle Hidden -FilePath "$inst\runtime\node.exe" -ArgumentList 'scripts\local.mjs' -WorkingDirectory "$inst\app" -RedirectStandardOutput "$env:RUNNER_TEMP\o.txt" -RedirectStandardError "$env:RUNNER_TEMP\e.txt"
  for($i=0;$i -lt 90;$i++){ try{ $r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3000/healthz; if($r.StatusCode -eq 200){return $p} }catch{}; Start-Sleep 2 }
  Get-Content "$env:RUNNER_TEMP\o.txt","$env:RUNNER_TEMP\e.txt" -ErrorAction SilentlyContinue; throw 'health timeout' }
function Stop-App($p){ Stop-Process -Id $p.Id -Force; Get-Process postgres -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep 3 }
$p=Start-App; "HEALTH OK (1st start)"
node "$PSScriptRoot\smoke.mjs" write
Stop-App $p
$p=Start-App; "HEALTH OK (restart)"
node "$PSScriptRoot\smoke.mjs" read
Stop-App $p
"SMOKE PASSED"
