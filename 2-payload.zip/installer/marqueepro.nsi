!include "MUI2.nsh"
Name "MarqueePro"
OutFile "MarqueePro-Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\MarqueePro"
RequestExecutionLevel user
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
Section "Install"
  SetOutPath "$INSTDIR"
  File /r "..\stage\*.*"
  CreateDirectory "$SMPROGRAMS\MarqueePro"
  CreateShortcut "$SMPROGRAMS\MarqueePro\MarqueePro.lnk" "$INSTDIR\installer\launch.cmd" "" "" "" SW_SHOWMINIMIZED
  CreateShortcut "$DESKTOP\MarqueePro.lnk" "$INSTDIR\installer\launch.cmd" "" "" "" SW_SHOWMINIMIZED
  CreateShortcut "$SMPROGRAMS\MarqueePro\Stop MarqueePro.lnk" "$INSTDIR\installer\stop.cmd" "" "" "" SW_SHOWMINIMIZED
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MarqueePro" "DisplayName" "MarqueePro"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MarqueePro" "UninstallString" "$INSTDIR\Uninstall.exe"
SectionEnd
Section "Uninstall"
  ; the data folder in %LOCALAPPDATA%\MarqueePro\data is kept on purpose
  Delete "$DESKTOP\MarqueePro.lnk"
  RMDir /r "$SMPROGRAMS\MarqueePro"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\MarqueePro"
SectionEnd
