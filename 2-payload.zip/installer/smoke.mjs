// Synthetic smoke client. Uses only the local server on this machine.
import fs from 'node:fs';
const mode = process.argv[2]; const B = 'http://127.0.0.1:3000';
const data = process.env.LOCALAPPDATA + '\\MarqueePro\\data'; const stateF = process.env.RUNNER_TEMP + '\\smoke-state.json';
const H = (cookie) => ({ 'content-type': 'application/json', 'x-requested-with': 'marqueepro', origin: B, ...(cookie ? { cookie } : {}) });
async function call(p, method, body, cookie) { const r = await fetch(B + p, { method, headers: H(cookie), body: body ? JSON.stringify(body) : undefined }); const t = await r.text(); let j; try { j = JSON.parse(t); } catch { j = t; } return { r, j }; }
async function login(u, pw) { const { r, j } = await call('/api/auth/login', 'POST', { username: u, password: pw }); if (r.status !== 200 && r.status !== 201) throw new Error('login failed ' + r.status); return { cookie: r.headers.getSetCookie().map((c) => c.split(';')[0]).join('; '), j }; }
const must = (c, m) => { if (!c) { console.error('FAIL: ' + m); process.exit(1); } console.log('ok: ' + m); };
if (mode === 'write') {
  const f = fs.readFileSync(data + '\\bootstrap-admin.txt', 'utf8'); const user = /username: (.+)/.exec(f)[1].trim(), pw = /password: (.+)/.exec(f)[1].trim();
  const a = await login(user, pw); must(a.j.must_change_password === true, 'first login forces password change');
  const np = 'SmokePass#98765x'; const ch = await call('/api/auth/change-password', 'POST', { current: pw, next: np }, a.cookie); must(ch.r.status === 200 || ch.r.status === 201, 'password changed');
  const b = await login(user, np); must(b.j.must_change_password === false, 'login with new password');
  const t = await call('/api/admin/tenants', 'POST', { name: 'Smoke Test Hall', owner_username: 'smoke_owner' }, b.cookie); must(t.r.status === 201 || t.r.status === 200, 'synthetic business written');
  fs.writeFileSync(stateF, JSON.stringify({ user, np }));
} else {
  const { user, np } = JSON.parse(fs.readFileSync(stateF, 'utf8')); const b = await login(user, np); must(true, 'login after restart with changed password');
  const l = await call('/api/admin/tenants', 'GET', null, b.cookie); must(Array.isArray(l.j) && l.j.some((x) => x.slug === 'smoke-test-hall'), 'written business read back after restart');
}
