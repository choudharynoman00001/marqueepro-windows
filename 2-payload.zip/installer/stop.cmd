@echo off
rem Stops the MarqueePro server and its private database. Your data is kept.
powershell -NoProfile -Command "$d=(Resolve-Path '%~dp0..').Path; Get-Process node,postgres -ErrorAction SilentlyContinue | Where-Object { $_.Path -like \"$d*\" } | Stop-Process -Force"
echo MarqueePro stopped.
