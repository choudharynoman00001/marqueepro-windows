@echo off
rem MarqueePro launcher. Starts the local server (if not already running), waits for it to be healthy,
rem then opens it in a Chromium app window (Edge or Chrome, no tabs or address bar).
rem This is the browser engine in its own window, not a native desktop app. If neither browser is found it falls back to the default browser.
rem Data stays in %LOCALAPPDATA%\MarqueePro\data on this PC.
setlocal enabledelayedexpansion
set "ROOT=%~dp0.."
set "MARQUEE_DATA=%LOCALAPPDATA%\MarqueePro\data"
if "%PORT%"=="" set "PORT=3000"
set "URL=http://localhost:%PORT%/"
if not exist "%MARQUEE_DATA%" mkdir "%MARQUEE_DATA%"
set "BR="
for %%B in ("%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe") do (
  if not defined BR if exist "%%~B" set "BR=%%~B"
)
if defined BR (
  echo mode=app-window> "%MARQUEE_DATA%\last-launch.txt"
  echo command="!BR!" --app=%URL%>> "%MARQUEE_DATA%\last-launch.txt"
) else (
  echo mode=fallback default-browser window> "%MARQUEE_DATA%\last-launch.txt"
  echo command=start %URL%>> "%MARQUEE_DATA%\last-launch.txt"
)
if defined MARQUEE_LAUNCH_LOG_ONLY exit /b 0
curl.exe -s -f -o nul http://127.0.0.1:%PORT%/healthz && goto open
start "MarqueePro server" /min /d "%ROOT%\app" "%ROOT%\runtime\node.exe" scripts\local.mjs
set /a N=0
:wait
curl.exe -s -f -o nul http://127.0.0.1:%PORT%/healthz && goto open
set /a N+=1
if !N! geq 90 ( echo MarqueePro did not start. See the server window. & pause & exit /b 1 )
timeout /t 2 /nobreak >nul
goto wait
:open
if defined BR ( start "" "!BR!" --app=%URL% ) else ( start "" "%URL%" )
exit /b 0
