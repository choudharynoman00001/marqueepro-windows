# Native-evidence variant: public CI logs carry only fixed classifications, never raw server output, commands or credentials.
# Silent install, start, health, login, password change, write, stop, restart, readback. Synthetic only.
# PostgreSQL refuses to run with administrator rights, and CI runs elevated, so the app is started with a
# limited (basic user) token via runas /trustlevel, which is also how a normal non-elevated PC runs it.
$ErrorActionPreference='Stop'
$inst="$env:LOCALAPPDATA\Programs\MarqueePro"; $data="$env:LOCALAPPDATA\MarqueePro\data"; $tmp=$env:RUNNER_TEMP
Start-Process -Wait -FilePath .\MarqueePro-Setup.exe -ArgumentList '/S'
if(-not (Test-Path "$inst\runtime\node.exe")){throw 'install missing'}
@"
@echo off
cd /d "$inst\app"
set MARQUEE_DATA=$data
set PORT=3000
set MARQUEE_DEBUG=1
"$inst\runtime\node.exe" scripts\local.mjs > "$tmp\o.txt" 2>&1
"@ | Set-Content "$tmp\run-restricted.cmd" -Encoding ascii
# Launcher selection check (log only, opens nothing): proves which browser mode and exact argv would be used. Not proof of window chrome.
$env:MARQUEE_LAUNCH_LOG_ONLY='1'; cmd /c "$inst\installer\launch.cmd"; Remove-Item Env:MARQUEE_LAUNCH_LOG_ONLY
$ll=Get-Content "$data\last-launch.txt" -Raw
if($ll -notmatch 'mode=app-window' -or $ll -notmatch '--app=http://localhost:3000/'){ throw 'launcher did not select app-window mode' }
"LAUNCHER APP-WINDOW SELECTION OK"
function Start-App{
  Remove-Item "$tmp\o.txt" -ErrorAction SilentlyContinue
  runas /trustlevel:0x20000 "$tmp\run-restricted.cmd"
  for($i=0;$i -lt 60;$i++){ try{ $r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3000/healthz; if($r.StatusCode -eq 200){return} }catch{}; Start-Sleep 2 }
  $lg=Get-Content "$tmp\o.txt" -Raw -ErrorAction SilentlyContinue; foreach($k in 'EADDRINUSE','EACCES','ECONNREFUSED','Missing dist','migrat','root','initdb','Cannot find module'){ if($lg -match [regex]::Escape($k)){ "SERVER LOG CLASS: $k" } }; throw 'health timeout' }
function Stop-App{ Get-Process node,postgres -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$inst*" } | Stop-Process -Force; Start-Sleep 4 }
Start-App; "HEALTH OK (1st start)"
node "$PSScriptRoot\smoke.mjs" write; if($LASTEXITCODE -ne 0){ throw "smoke write failed" }
Stop-App
Start-App; "HEALTH OK (restart)"
# Real launch (informational, not a gate): server is healthy, so the launcher goes straight to opening the browser window.
cmd /c "$inst\installer\launch.cmd"; Start-Sleep 8
$bp=Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'msedge|chrome' -and $_.CommandLine -match '--app=http://localhost:3000/' }
if($bp){ "REAL LAUNCH PROCESS FOUND" } else { "REAL LAUNCH PROCESS NOT FOUND (informational)" }
if($bp){ $bp | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } }
node "$PSScriptRoot\smoke.mjs" read; if($LASTEXITCODE -ne 0){ throw "smoke read failed" }
# Informational: headless Edge page screenshots of the installed app (not a gate, not window chrome).
try {
  $sd="$env:RUNNER_TEMP\shots"; New-Item -ItemType Directory $sd -Force | Out-Null; Copy-Item "$PSScriptRoot\shots.mjs" $sd
  Push-Location $sd; npm init -y | Out-Null; npm install puppeteer-core --no-audit --no-fund 2>&1 | Out-Null
  $env:EDGE=(Get-Command msedge -ErrorAction SilentlyContinue).Source; if(-not $env:EDGE){ $env:EDGE="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" }
  node shots.mjs; Pop-Location
} catch { Write-Host "SHOTS FAILED (informational)"; Pop-Location }
Stop-App
"SMOKE PASSED"
