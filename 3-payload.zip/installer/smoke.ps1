# Silent install, start, health, login, password change, write, stop, restart, readback. Synthetic only.
# PostgreSQL refuses to run with administrator rights, and CI runs elevated, so the app is started with a
# limited (basic user) token via runas /trustlevel, which is also how a normal non-elevated PC runs it.
$ErrorActionPreference='Stop'
$inst="$env:LOCALAPPDATA\Programs\MarqueePro"; $data="$env:LOCALAPPDATA\MarqueePro\data"; $tmp=$env:RUNNER_TEMP
Start-Process -Wait -FilePath .\MarqueePro-Setup.exe -ArgumentList '/S'
if(-not (Test-Path "$inst\runtime\node.exe")){throw 'install missing'}
@"
@echo off
cd /d "$inst\app"
set MARQUEE_DATA=$data
set PORT=3000
set MARQUEE_DEBUG=1
"$inst\runtime\node.exe" scripts\local.mjs > "$tmp\o.txt" 2>&1
"@ | Set-Content "$tmp\run-restricted.cmd" -Encoding ascii
function Start-App{
  Remove-Item "$tmp\o.txt" -ErrorAction SilentlyContinue
  runas /trustlevel:0x20000 "$tmp\run-restricted.cmd"
  for($i=0;$i -lt 60;$i++){ try{ $r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:3000/healthz; if($r.StatusCode -eq 200){return} }catch{}; Start-Sleep 2 }
  Write-Host (Get-Content "$tmp\o.txt" -Raw -ErrorAction SilentlyContinue); throw 'health timeout' }
function Stop-App{ Get-Process node,postgres -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$inst*" } | Stop-Process -Force; Start-Sleep 4 }
Start-App; "HEALTH OK (1st start)"
node "$PSScriptRoot\smoke.mjs" write
Stop-App
Start-App; "HEALTH OK (restart)"
node "$PSScriptRoot\smoke.mjs" read
Stop-App
"SMOKE PASSED"
