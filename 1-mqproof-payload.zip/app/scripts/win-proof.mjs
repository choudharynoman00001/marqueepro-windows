// Windows proof script (NOT yet run anywhere). Intended for ONE manual run on a Windows runner, after the source is frozen.
// It checks, on real NTFS: folder/file/database-tree permissions, the integration key file, a second local account being refused,
// a restart that re-verifies, and the refusal to reset an empty password file when a database exists.
// It uses only synthetic data in C:\mqproof. It never contacts any provider. Output: win-proof-result.json (exit code 1 if any check fails).
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import http from 'node:http';
if (process.platform !== 'win32') { console.error('This proof only means something on Windows.'); process.exit(2); }
if (process.env.GITHUB_ACTIONS !== 'true') { console.error('This proof only runs inside the dedicated CI workflow (it creates and deletes a local account and a folder).'); process.exit(2); }
const root = process.cwd(); const base = 'C:\\mqproof'; const data = path.join(base, 'data'); const MARK = path.join(base, '.mqproof-owned');
const toUrl = (p) => new URL('file:///' + path.resolve(p).replace(/\\/g, '/')).href;
const { sddlUnexpectedSids, localAccountAliases } = await import(toUrl(path.join(root, 'dist/src/fsacl.js')));
const sys = process.env.SystemRoot || 'C:\\Windows'; const ICACLS = path.join(sys, 'System32', 'icacls.exe'); const WHOAMI = path.join(sys, 'System32', 'whoami.exe');
const PROBE = 'mqp' + Math.random().toString(16).slice(2, 10); const PW = 'Mq!' + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2) + 'Zz9';
// Nothing printed or stored may contain the temporary password or a connection string.
const clean = (t) => String(t ?? '').split(PW).join('[pw]').replace(/postgres(ql)?:\/\/\S+/g, '[db-url]').replace(/\s+/g, ' ').slice(0, 200);
const results = []; const check = (name, ok, detail = '') => { const d = clean(detail); results.push({ name, ok: !!ok, detail: d }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (d ? ' - ' + d : '')); };
const run = (exe, args, o = {}) => spawnSync(exe, args, { encoding: 'utf8', windowsHide: true, ...o });
const me = run(WHOAMI, ['/user', '/fo', 'csv', '/nh']).stdout.trim().split(',')[1]?.replace(/"/g, '').trim();
check('own account SID found', /^S-1-5-/.test(me || ''), me);
const allowed = [me, 'S-1-5-18', 'S-1-5-32-544'];
if (fs.existsSync(base)) { if (!fs.existsSync(MARK)) { console.error('C:\\mqproof exists and was not created by this proof. Nothing was changed.'); process.exit(2); } fs.rmSync(base, { recursive: true, force: true }); }
fs.mkdirSync(base, { recursive: true }); fs.writeFileSync(MARK, 'created by win-proof.mjs\n');
let created = false;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const get = (u) => new Promise((res) => { http.get(u, (r) => { r.resume(); res(r.statusCode); }).on('error', () => res(0)); });
// PostgreSQL refuses to start under a user with administrative permissions (src/backend/main/main.c, check_root, WIN32 branch), and the hosted runner is an elevated administrator.
// So the launcher is started the same way the earlier build smoke did (installer/smoke-native.ps1, v48): `runas /trustlevel:0x20000` (a basic-user token of the SAME account, which is how a normal non-elevated PC runs it).
// The proof script itself stays elevated for its checks. The launcher writes to a file in the runner temp folder; only fixed-prefix launcher messages are ever shown. The debug switch is not used and no database line is printed.
const TOKEN = 'mqp' + Math.random().toString(16).slice(2, 10); const TMP = process.env.RUNNER_TEMP || os.tmpdir();
const outFile = path.join(TMP, `mqproof-launcher-${TOKEN}.txt`); const cmdFile = path.join(TMP, `mqproof-launch-${TOKEN}.cmd`); const tokFile = path.join(TMP, `mqproof-token-${TOKEN}.txt`); const psFile = path.join(TMP, `mqproof-token-${TOKEN}.ps1`);
const FIXED = /^(MarqueePro cannot start: the database (initialise|start) step failed \((error|stopped without an error); reason class: [A-Za-z ()]+\)|MarqueePro is running)/;
const fixedLines = (t) => String(t).split(/\r?\n/).map((l) => (/^Cannot protect /.test(l) ? 'launcher refused to start: could not protect a file or folder (details withheld)' : l)).filter((l) => FIXED.test(l) || /^launcher refused to start: could not protect/.test(l)).slice(0, 3).join(' | ');
const PS = path.join(sys, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
// Only the exact launcher started by this script and its descendants are ever stopped: found through the unique command-file name (passed by environment, never on a command line), never by image name, never this script or its ancestors.
const mine = () => { const r = run(PS, ['-NoProfile', '-NonInteractive', '-Command', "$all=@(Get-CimInstance Win32_Process); $skip=@{}; $c=[int]$env:MQ_SELF; while($c -and -not $skip.ContainsKey($c)){ $skip[$c]=1; $q=$all|Where-Object{$_.ProcessId -eq $c}|Select-Object -First 1; $c=if($q){[int]$q.ParentProcessId}else{0} }; $set=@{}; $all|Where-Object{ $_.CommandLine -and $_.CommandLine.Contains($env:MQ_TOKEN) -and -not $skip.ContainsKey([int]$_.ProcessId) }|ForEach-Object{ $set[[int]$_.ProcessId]=1 }; $grow=$true; while($grow){ $grow=$false; foreach($p in $all){ if($set.ContainsKey([int]$p.ParentProcessId) -and -not $set.ContainsKey([int]$p.ProcessId) -and -not $skip.ContainsKey([int]$p.ProcessId)){ $set[[int]$p.ProcessId]=1; $grow=$true } } }; $set.Keys"], { env: { ...process.env, MQ_TOKEN: TOKEN, MQ_SELF: String(process.pid) } }); return String(r.stdout || '').split(/\s+/).filter((x) => /^\d+$/.test(x)); };
let log = '';
async function start(label) {
  fs.rmSync(outFile, { force: true }); fs.rmSync(tokFile, { force: true });
  fs.writeFileSync(psFile, "$id=[Security.Principal.WindowsIdentity]::GetCurrent(); $p=New-Object Security.Principal.WindowsPrincipal($id); \"admin=$($p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) samesid=$($id.User.Value -eq $env:MQ_ME)\" | Set-Content -Encoding ascii $env:MQ_TOKFILE\r\n", 'ascii');
  fs.writeFileSync(cmdFile, `@echo off\r\nset MQ_ME=${me}\r\nset MQ_TOKFILE=${tokFile}\r\n"${PS}" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "${psFile}"\r\ncd /d "${root}"\r\nset MARQUEE_DATA=${data}\r\nset PORT=3911\r\nset PGPORT=54911\r\n"${process.execPath}" scripts\\local.mjs > "${outFile}" 2>&1\r\n`, 'ascii');
  const ru = run('runas', ['/trustlevel:0x20000', cmdFile]); if (ru.status !== 0) { check(label + ': launcher started', false, 'runas exit ' + ru.status); return false; }
  // The claim "restricted launcher" is observed from inside that launcher, not inferred from PostgreSQL starting.
  let tk = ''; const tt = Date.now(); while (Date.now() - tt < 60000 && !/admin=\w+ samesid=\w+/.test(tk)) { await sleep(500); try { tk = fs.readFileSync(tokFile, 'utf8'); } catch { tk = ''; } }
  const adm = /admin=(\w+)/.exec(tk)?.[1]; const same = /samesid=(\w+)/.exec(tk)?.[1];
  const restricted = adm === 'False' && same === 'True'; check(label + ': launcher token observed (not administrator, same account)', restricted, `administrator role ${adm ?? 'not observed'}, same account SID ${same ?? 'not observed'}`);
  if (!restricted) { stop(); return false; }
  const t0 = Date.now(); log = '';
  while (Date.now() - t0 < 240000) { try { log = fs.readFileSync(outFile, 'utf8'); } catch { log = ''; } if (/MarqueePro is running/.test(log) || /MarqueePro cannot start|Cannot protect|will not start/.test(log)) break; await sleep(1000); }
  const up = /MarqueePro is running/.test(log); check(label + ': launcher started', up, up ? '' : (fixedLines(log) || `no recognised launcher message (${log.length} bytes)`)); return up;
}
function stop() { for (const pid of mine()) run('taskkill', ['/PID', pid, '/T', '/F']); }
let aliasNote = '';
function aliasesOrNone() { try { const r = localAccountAliases(); aliasNote = Object.keys(r).length ? '' : 'alias lookup returned no accounts'; return r; } catch (e) { aliasNote = String(e && e.message).replace(/[^\x20-\x7e]/g, '').slice(0, 80); return {}; } }
function aclCheck(label, target, tree) {
  const out = path.join(base, 'acl-' + Math.random().toString(16).slice(2) + '.txt'); const r = run(ICACLS, [target, '/save', out, ...(tree ? ['/T', '/C'] : [])]);
  if (r.status !== 0 || !fs.existsSync(out)) return check(label, false, 'icacls failed ' + (r.stderr || r.stdout));
  const txt = fs.readFileSync(out, 'utf16le').includes('D:') ? fs.readFileSync(out, 'utf16le') : fs.readFileSync(out, 'utf8'); const lines = txt.split(/\r?\n/).filter((l) => /^D:/.test(l));
  const bad = lines.flatMap((l) => sddlUnexpectedSids(l, allowed, aliasesOrNone()));
  check(label, lines.length > 0 && bad.length === 0, `${lines.length} entries read, unexpected trustees: ${[...new Set(bad)].join(' ') || 'none'}${aliasNote ? ' (' + aliasNote + ')' : ''}`); if (tree) check(label + ' (covers many entries)', lines.length >= 20, lines.length);
}
async function stateChecks(tag) {
  aclCheck(tag + ': data folder', data, false); aclCheck(tag + ': local-secrets.json', path.join(data, 'local-secrets.json'), false); aclCheck(tag + ': database folder, every entry', path.join(data, 'pg'), true);
  check(tag + ': web answers', (await get('http://127.0.0.1:3911/')) === 200);
}
try {
  if (await start('first start')) {
    await stateChecks('first start');
    // key file: created through the real sealing code with DATA_DIR on this folder
    const sealer = run(process.execPath, ['-e', `import(${JSON.stringify(toUrl(path.join(root, 'dist/src/integrations.js')))}).then(m=>{const s=m.seal({x:1},'a');console.log(s.length>10?'sealed':'no')})`], { env: { ...process.env, DATA_DIR: data, NODE_ENV: 'production' } });
    check('integration key file created by real code', /sealed/.test(sealer.stdout) && fs.existsSync(path.join(data, 'integration.key')), 'exit ' + sealer.status);
    aclCheck('integration.key', path.join(data, 'integration.key'), false);
    // a second local account must be refused. Exit 3 means EACCES/EPERM only; any other failure is exit 4 and fails the check, and the target must exist.
    const exists = (await Promise.resolve([path.join(data, 'local-secrets.json'), path.join(data, 'integration.key'), path.join(data, 'bootstrap-admin.txt')])).map((f) => [f, fs.existsSync(f)]);
    for (const [f, ok] of exists) check('target exists: ' + path.basename(f), ok);
    aclCheck('bootstrap-admin.txt', path.join(data, 'bootstrap-admin.txt'), false);
    const pre = run('net', ['user', PROBE]); check('probe account name unused before this run', pre.status !== 0);
    if (pre.status !== 0) {
      const add = run('net', ['user', PROBE, PW, '/add']); created = add.status === 0; check('second local account created', created, 'exit ' + add.status);
      if (created) {
        fs.writeFileSync(path.join(base, 'control.txt'), 'readable control\n');
        fs.writeFileSync(path.join(base, 'probe.js'), "const fs=require('fs');try{if(process.argv[3]==='dir')fs.readdirSync(process.argv[2]);else fs.readFileSync(process.argv[2]);process.exit(0)}catch(e){process.exit(e.code==='EACCES'||e.code==='EPERM'?3:4)}\n");
        const asProbe = (file, mode = 'file') => { const ps = "$p=ConvertTo-SecureString $env:MQ_PW -AsPlainText -Force; $c=New-Object System.Management.Automation.PSCredential('.\\' + $env:MQ_USER,$p); $pr=Start-Process -FilePath $env:MQ_NODE -ArgumentList @($env:MQ_PROBE,$env:MQ_FILE,$env:MQ_MODE) -Credential $c -WorkingDirectory $env:MQ_DIR -PassThru -Wait -WindowStyle Hidden -LoadUserProfile; exit $pr.ExitCode"; return run('powershell', ['-NoProfile', '-Command', ps], { env: { ...process.env, MQ_PW: PW, MQ_USER: PROBE, MQ_NODE: process.execPath, MQ_PROBE: path.join(base, 'probe.js'), MQ_FILE: file, MQ_MODE: mode, MQ_DIR: base } }); };
        const ctl = asProbe(path.join(base, 'control.txt')); check('control file readable by the second account', ctl.status === 0, 'exit ' + ctl.status);
        for (const f of ['local-secrets.json', 'integration.key', 'bootstrap-admin.txt']) { const r = asProbe(path.join(data, f)); check(f + ' refused to the second account (EACCES/EPERM)', r.status === 3, 'exit ' + r.status); }
        const dd = asProbe(data, 'dir'); check('data folder listing refused to the second account (EACCES/EPERM)', dd.status === 3, 'exit ' + dd.status); const pd = asProbe(path.join(data, 'pg'), 'dir'); check('database folder listing refused to the second account (EACCES/EPERM)', pd.status === 3, 'exit ' + pd.status);
        const d = asProbe(path.join(data, 'pg', 'PG_VERSION')); check('database folder file refused to the second account (EACCES/EPERM)', d.status === 3, 'exit ' + d.status);
      }
    }
    stop(); await sleep(5000);
    if (await start('restart')) { await stateChecks('restart'); }
    stop(); await sleep(5000);
    // empty password file while a database exists: must refuse and must not reset it
    const sf = path.join(data, 'local-secrets.json'); const keep = fs.readFileSync(sf, 'utf8'); fs.writeFileSync(sf, '');
    const t = spawnSync(process.execPath, ['scripts/local.mjs'], { cwd: root, encoding: 'utf8', timeout: 120000, env: { ...process.env, MARQUEE_DATA: data, PORT: '3911', PGPORT: '54911' } });
    check('empty password file with a database: start refused', t.status !== 0 && /NOT reset/.test(t.stdout + t.stderr), `exit ${t.status}`); check('empty password file left empty (not reset)', fs.readFileSync(sf, 'utf8') === '');
    fs.writeFileSync(sf, keep);
  }
} catch (e) { check('script error', false, e.message || e); } finally { stop(); if (created) { const del = run('net', ['user', PROBE, '/delete']); if (del.status !== 0) console.log('WARNING: could not delete the temporary account ' + PROBE + '; the runner is discarded after the job.'); } }
fs.writeFileSync('win-proof-result.json', JSON.stringify({ when: new Date().toISOString(), node: process.version, os: process.env.OS, note: 'Hosted runner accounts are administrators: this proof does not claim protection from administrators.', results }, null, 2));
process.exit(results.every((r) => r.ok) ? 0 : 1);
