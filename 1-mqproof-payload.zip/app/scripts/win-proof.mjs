// Windows proof script (NOT yet run anywhere). Intended for ONE manual run on a Windows runner, after the source is frozen.
// It checks, on real NTFS: folder/file/database-tree permissions, the integration key file, a second local account being refused,
// a restart that re-verifies, and the refusal to reset an empty password file when a database exists.
// It uses only synthetic data in C:\mqproof. It never contacts any provider. Output: win-proof-result.json (exit code 1 if any check fails).
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import http from 'node:http';
if (process.platform !== 'win32') { console.error('This proof only means something on Windows.'); process.exit(2); }
if (process.env.GITHUB_ACTIONS !== 'true') { console.error('This proof only runs inside the dedicated CI workflow (it creates and deletes a local account and a folder).'); process.exit(2); }
const root = process.cwd(); const base = 'C:\\mqproof'; const data = path.join(base, 'data'); const MARK = path.join(base, '.mqproof-owned');
const toUrl = (p) => new URL('file:///' + path.resolve(p).replace(/\\/g, '/')).href;
const { sddlUnexpectedSids, localAccountAliases } = await import(toUrl(path.join(root, 'dist/src/fsacl.js')));
const sys = process.env.SystemRoot || 'C:\\Windows'; const ICACLS = path.join(sys, 'System32', 'icacls.exe'); const WHOAMI = path.join(sys, 'System32', 'whoami.exe');
const PROBE = 'mqp' + Math.random().toString(16).slice(2, 10); const PW = 'Mq!' + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2) + 'Zz9';
// Nothing printed or stored may contain the temporary password or a connection string.
const clean = (t) => String(t ?? '').split(PW).join('[pw]').replace(/postgres(ql)?:\/\/\S+/g, '[db-url]').replace(/\s+/g, ' ').slice(0, 200);
const results = []; const check = (name, ok, detail = '') => { const d = clean(detail); results.push({ name, ok: !!ok, detail: d }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (d ? ' - ' + d : '')); };
// Failure facts are separate short records, each checked for cutting by clean(): a cut record is marked, never silently shortened.
const facts = []; const fact = (name, detail) => { const raw = String(detail ?? ''); const d = clean(raw); const cut = d !== raw; const rec = cut ? d.slice(0, 180) + ' [TRUNCATED]' : d; facts.push({ name, detail: rec }); console.log('INFO ' + name + ' - ' + rec); };
const run = (exe, args, o = {}) => spawnSync(exe, args, { encoding: 'utf8', windowsHide: true, ...o });
const me = run(WHOAMI, ['/user', '/fo', 'csv', '/nh']).stdout.trim().split(',')[1]?.replace(/"/g, '').trim();
check('own account SID found', /^S-1-5-/.test(me || ''), me);
const allowed = [me, 'S-1-5-18', 'S-1-5-32-544'];
if (fs.existsSync(base)) { if (!fs.existsSync(MARK)) { console.error('C:\\mqproof exists and was not created by this proof. Nothing was changed.'); process.exit(2); } fs.rmSync(base, { recursive: true, force: true }); }
fs.mkdirSync(base, { recursive: true }); fs.writeFileSync(MARK, 'created by win-proof.mjs\n');
let created = false; let ownedAccount = false;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const get = (u) => new Promise((res) => { http.get(u, (r) => { r.resume(); res(r.statusCode); }).on('error', () => res(0)); });
// PostgreSQL refuses to start under a user with administrative permissions (src/backend/main/main.c, check_root, WIN32 branch), and the hosted runner is an elevated administrator.
// So the launcher is started the same way the earlier build smoke did (installer/smoke-native.ps1, v48): `runas /trustlevel:0x20000` (a basic-user token of the SAME account, which is how a normal non-elevated PC runs it).
// The proof script itself stays elevated for its checks. The launcher writes to a file in the runner temp folder; only fixed-prefix launcher messages are ever shown. The debug switch is not used and no database line is printed.
const TOKEN = 'mqp' + Math.random().toString(16).slice(2, 10); const TMP = process.env.RUNNER_TEMP || os.tmpdir();
const outFile = path.join(TMP, `mqproof-launcher-${TOKEN}.txt`); const cmdFile = path.join(TMP, `mqproof-launch-${TOKEN}.cmd`); const tokFile = path.join(TMP, `mqproof-token-${TOKEN}.txt`); const phaseFile = path.join(TMP, `mqproof-phase-${TOKEN}.txt`); const psFile = path.join(TMP, `mqproof-token-${TOKEN}.ps1`);
const FIXED = /^(MarqueePro cannot start: the database (initialise|start) step failed \((error|stopped without an error); reason class: [A-Za-z ()]+\)|MarqueePro stopped: phase=[a-z-]+; error=[A-Z_]+; code=[A-Z_]+\. Any database process it started may still be running\.|MarqueePro is running)/;
const fixedLines = (t) => String(t).split(/\r?\n/).map((l) => (/^Cannot protect /.test(l) ? 'launcher refused to start: could not protect a file or folder (details withheld)' : l)).filter((l) => FIXED.test(l) || /^launcher refused to start: could not protect/.test(l)).slice(0, 3).join(' | ');
const PS = path.join(sys, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
// Only the exact launcher started by this script and its descendants are ever stopped: found through the unique command-file name (passed by environment, never on a command line), never by image name, never this script or its ancestors.
const mine = () => { const r = run(PS, ['-NoProfile', '-NonInteractive', '-Command', "$all=@(Get-CimInstance Win32_Process); $skip=@{}; $c=[int]$env:MQ_SELF; while($c -and -not $skip.ContainsKey($c)){ $skip[$c]=1; $q=$all|Where-Object{$_.ProcessId -eq $c}|Select-Object -First 1; $c=if($q){[int]$q.ParentProcessId}else{0} }; $set=@{}; $all|Where-Object{ $_.CommandLine -and $_.CommandLine.Contains($env:MQ_TOKEN) -and -not $skip.ContainsKey([int]$_.ProcessId) }|ForEach-Object{ $set[[int]$_.ProcessId]=1 }; $grow=$true; while($grow){ $grow=$false; foreach($p in $all){ if($set.ContainsKey([int]$p.ParentProcessId) -and -not $set.ContainsKey([int]$p.ProcessId) -and -not $skip.ContainsKey([int]$p.ProcessId)){ $set[[int]$p.ProcessId]=1; $grow=$true } } }; $set.Keys"], { env: { ...process.env, MQ_TOKEN: TOKEN, MQ_SELF: String(process.pid) } }); if (r.error || r.status !== 0) return null; return String(r.stdout || '').split(/\s+/).filter((x) => /^\d+$/.test(x)); };
let log = '';
// SHAPE-START
// Closed-shape observation of unrecognised launcher output. It only reports which fixed tokens appear on whole lines of a Node crash report; it never echoes text, never uses the byte size, and never says what caused the crash.
// A crash report is only classified when it ends with Node's own "Node.js v<version>" trailer line. Conflicting or repeated different tokens are AMBIGUOUS; no tokens is UNKNOWN.
const SHAPE_SYSCALLS = ['stat', 'chmod', 'spawn']; const SHAPE_CODES = ['ENOENT', 'EACCES', 'EPERM', 'EBUSY', 'ENOTDIR', 'EISDIR', 'EMFILE'];
function classifyShape(text) {
  const lines = String(text ?? '').split(/\r?\n/);
  if (!lines.some((l) => /^Node\.js v\d{1,3}\.\d{1,3}\.\d{1,3}\s*$/.test(l))) return 'UNKNOWN (no Node crash trailer line)';
  const sys = new Set(); const codes = new Set(); let unhandledEvent = false; let childEmitter = false;
  for (const l of lines) {
    let m;
    if ((m = /^ {2}syscall: '([a-z]+)(?: [^']*)?',?\s*$/.exec(l))) sys.add(SHAPE_SYSCALLS.includes(m[1]) ? m[1] : 'other');
    else if ((m = /^ {2}code: '([A-Z]+)',?\s*$/.exec(l))) codes.add(SHAPE_CODES.includes(m[1]) ? m[1] : 'other');
    else if (/^ {6}throw er; \/\/ Unhandled 'error' event\s*$/.test(l)) unhandledEvent = true;
    else if (/^Emitted 'error' event on ChildProcess instance at:\s*$/.test(l)) childEmitter = true;
  }
  if (!sys.size && !codes.size && !unhandledEvent && !childEmitter) return 'UNKNOWN (no recognised tokens)';
  if (sys.size > 1 || codes.size > 1) return 'AMBIGUOUS (more than one different token)';
  return 'tokens: syscall=' + ([...sys][0] ?? 'not shown') + '; code=' + ([...codes][0] ?? 'not shown') + '; unhandled-error-event line=' + (unhandledEvent ? 'yes' : 'no') + '; child-process emitter line=' + (childEmitter ? 'yes' : 'no');
}
// Which of the two resolved vendor files a crash report names. Only a single, exact, full-line path token in the form Node prints (backslashes doubled) counts. Nothing is echoed.
function fileLabel(text, paths) {
  const lines = String(text ?? '').split(/\r?\n/);
  if (!lines.some((l) => /^Node\.js v\d{1,3}\.\d{1,3}\.\d{1,3}\s*$/.test(l))) return 'UNKNOWN (no Node crash trailer line)';
  if (!paths || typeof paths.postgres !== 'string' || typeof paths.initdb !== 'string') return 'UNKNOWN (vendor paths not resolved)';
  const toks = new Set(); for (const l of lines) { const m = /^ {2}path: '(.*)',?\s*$/.exec(l); if (m) toks.add(m[1]); }
  if (!toks.size) return 'UNKNOWN (no path line)'; if (toks.size > 1) return 'AMBIGUOUS (more than one different path line)';
  const tok = [...toks][0]; if (tok.includes("'") || /[\u0000-\u001f]/.test(tok)) return 'UNKNOWN (unparseable path line)';
  const esc = (p) => p.replace(/\\/g, '\\\\'); const isP = tok === esc(paths.postgres); const isI = tok === esc(paths.initdb);
  if (isP && isI) return 'AMBIGUOUS (both vendor paths are identical)';
  if (isP) return 'file=postgres'; if (isI) return 'file=initdb';
  if (tok === paths.postgres || tok === paths.initdb) return 'UNKNOWN (path not in the form Node prints)';
  return 'no exact match with either vendor path';
}
// Closed description of one finished spawnSync of net.exe: how it ended and which known whole-line message (if any) it printed. Nothing raw is returned.
const NET_MSGS = [['LONG_PASSWORD_PROMPT', /^The password entered is longer than 14 characters\./], ['COMPLETED_OK', /^The command completed successfully\.\s*$/], ['POLICY_TEXT', /^The password does not meet the password policy requirements/], ['ACCOUNT_EXISTS_TEXT', /^The account already exists\.\s*$/], ['USER_NOT_FOUND_TEXT', /^The user name could not be found\.\s*$/], ['ACCESS_DENIED_TEXT', /^System error 5 has occurred\.\s*$/]];
function netMessage(r) { const hit = new Set(); for (const l of (String((r && r.stdout) ?? '') + '\n' + String((r && r.stderr) ?? '')).split(/\r?\n/)) for (const [k, re] of NET_MSGS) if (re.test(l)) hit.add(k); return hit.size === 0 ? 'none recognised' : hit.size === 1 ? [...hit][0] : 'AMBIGUOUS'; }
// net ran to the end: no spawn error, an integer exit status, no signal.
const netRan = (r) => !!r && !r.error && Number.isInteger(r.status) && !r.signal;
// The name is proven free only by a finished net lookup with a nonzero status and exactly the "user name could not be found" message. Anything else is not proof.
const netProvesAbsent = (r) => netRan(r) && r.status !== 0 && netMessage(r) === 'USER_NOT_FOUND_TEXT';
const netProvesPresent = (r) => netRan(r) && r.status === 0 && netMessage(r) === 'COMPLETED_OK';
function summarizeNet(r) {
  const err = r && r.error ? (['ENOENT', 'EACCES', 'EPERM', 'ETIMEDOUT'].includes(r.error.code) ? r.error.code : 'OTHER') : 'none';
  const st = r && Number.isInteger(r.status) ? String(r.status) : 'null'; const sg = r && r.signal ? (['SIGTERM', 'SIGKILL'].includes(r.signal) ? r.signal : 'OTHER') : 'none';
  const out = netMessage(r);
  return 'spawn error=' + err + '; exit status=' + st + '; signal=' + sg + '; known message=' + out;
}
// Account creation goes through the documented New-LocalUser cmdlet (SecureString password read from the environment, never from the command line): net.exe asks a confirmation above 14 characters and has no documented switch to answer it. Exit codes are a closed set; nothing raw is returned.
const PS_TYPES = ['UserExistsException', 'InvalidPasswordException', 'AccessDeniedException', 'CommandNotFoundException', 'ParameterBindingException', 'ParameterBindingValidationException', 'ParameterBindingArgumentTransformationException', 'FileNotFoundException', 'PrivilegeNotHeldException', 'InvalidNameException', 'NotSupportedException', 'InvalidOperationException', 'ArgumentException', 'UnauthorizedAccessException', 'MethodInvocationException', 'RuntimeException', 'Win32Exception', 'InvalidCredentialException'];
const PS_IDS = ['UserExists', 'InvalidPassword', 'AccessDenied', 'CommandNotFoundException', 'ParameterArgumentValidationError', 'ParameterArgumentTransformationError', 'NamedParameterNotFound', 'MissingMandatoryParameter', 'InvalidName', 'PrivilegeNotHeld', 'Modules_ModuleNotFound', 'InvalidOperationException', 'PathNotFound'];
const PS_ADD = [
  "$ErrorActionPreference='Stop'; $st='import';",
  '$T=@(' + PS_TYPES.map((x) => "'" + x + "'").join(',') + '); $I=@(' + PS_IDS.map((x) => "'" + x + "'").join(',') + ');',
  "function MqDiag($ty,$id){ $b = if([Environment]::Is64BitProcess){'64'}else{'32'}; $ad = if(([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){'yes'}else{'no'}; $cm = if(Get-Command New-LocalUser -ErrorAction SilentlyContinue){'yes'}else{'no'}; $m7 = if($env:PSModulePath -match 'PowerShell.7'){'yes'}else{'no'}; Write-Output ('MQDIAG stage=' + $st + ' type=' + $ty + ' id=' + $id + ' ps=' + $PSVersionTable.PSVersion.Major + ' bits=' + $b + ' admin=' + $ad + ' cmd=' + $cm + ' childmod7=' + $m7) }",
  "try { Import-Module Microsoft.PowerShell.LocalAccounts; $st='secure'; $s = ConvertTo-SecureString $env:MQ_PW -AsPlainText -Force; $st='create'; New-LocalUser -Name $env:MQ_USER -Password $s | Out-Null; exit 0 }",
  "catch { $n = $_.Exception.GetType().Name; $f = ($_.FullyQualifiedErrorId -split ',')[0]; $ty = if($T -contains $n){$n}else{'other'}; $id = if($I -contains $f){$f}else{'other'}; MqDiag $ty $id; if ($n -eq 'UserExistsException') { exit 10 } elseif ($n -eq 'InvalidPasswordException') { exit 11 } elseif ($n -eq 'AccessDeniedException') { exit 12 } else { exit 13 } }",
].join(' ');
// One exact whole-line record, every value from a closed list or a small integer; anything else is reported as missing. Never the message, the name or the password.
const PS_DIAG_RE = new RegExp('^MQDIAG stage=(import|secure|create) type=(' + PS_TYPES.join('|') + '|other) id=(' + PS_IDS.join('|') + '|other) ps=\\d{1,2} bits=(32|64) admin=(yes|no) cmd=(yes|no) childmod7=(yes|no)$');
function psDiag(r) { const hits = String((r && r.stdout) ?? '').split(/\r?\n/).map((l) => l.trim()).filter((l) => l.startsWith('MQDIAG')); const [h0, h1] = hits; return h0 !== undefined && h1 === undefined && PS_DIAG_RE.test(h0) ? h0.slice(7) : 'not available (no single well-formed record)'; }
const PS_PROBE = [
  "$ErrorActionPreference='Stop'; $st='prep'; $ty='none'; $id='none'; $inn='none'; $nat='none'; $code='none'; $sl='missing'; $sk='none'; $nd='no'; $wk='no'; $fl='no';",
  '$T=@(' + PS_TYPES.map((x) => "'" + x + "'").join(',') + '); $I=@(' + PS_IDS.map((x) => "'" + x + "'").join(',') + ');',
  "function MqRecord { $b = if([Environment]::Is64BitProcess){'64'}else{'32'}; $ad = if(([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){'yes'}else{'no'}; Write-Output ('MQPROBE stage=' + $st + ' type=' + $ty + ' id=' + $id + ' inner=' + $inn + ' native=' + $nat + ' code=' + $code + ' admin=' + $ad + ' bits=' + $b + ' seclogon=' + $sl + ' start=' + $sk + ' node=' + $nd + ' work=' + $wk + ' file=' + $fl) }",
  "try { if (Test-Path -LiteralPath $env:MQ_NODE) { $nd='yes' }; if (Test-Path -LiteralPath $env:MQ_DIR) { $wk='yes' }; if (Test-Path -LiteralPath $env:MQ_FILE) { $fl='yes' };",
  "$svc = Get-Service -Name seclogon -ErrorAction SilentlyContinue; if ($svc) { $sl = if ($svc.Status -eq 'Running') {'running'} elseif ($svc.Status -eq 'Stopped') {'stopped'} else {'other'}; $sk = if ($svc.StartType -eq 'Disabled') {'disabled'} elseif ($svc.StartType -eq 'Manual') {'manual'} elseif ($svc.StartType -eq 'Automatic') {'automatic'} else {'other'} };",
  "$st='cred'; $p = ConvertTo-SecureString $env:MQ_PW -AsPlainText -Force; $c = New-Object System.Management.Automation.PSCredential('.\\' + $env:MQ_USER, $p);",
  "$st='launch'; $pr = Start-Process -FilePath $env:MQ_NODE -ArgumentList @($env:MQ_PROBE, $env:MQ_FILE, $env:MQ_MODE) -Credential $c -WorkingDirectory $env:MQ_DIR -PassThru -WindowStyle Hidden -LoadUserProfile -ErrorAction Stop;",
  "$st='wait'; if ($null -eq $pr) { MqRecord; exit 92 }; $null = $pr.Handle; if (-not $pr.WaitForExit(90000)) { MqRecord; exit 93 }; $pr.WaitForExit();",
  "$st='exit'; $ec = $pr.ExitCode; if ($null -eq $ec) { MqRecord; exit 92 }; $code = [string][int]$ec; MqRecord; exit ([int]$ec) }",
  "catch { $e = $_.Exception; $n = $e.GetType().Name; $f = ($_.FullyQualifiedErrorId -split ',')[0]; $ty = if($T -contains $n){$n}else{'other'}; $id = if($I -contains $f){$f}else{'other'}; if ($e.InnerException) { $m = $e.InnerException.GetType().Name; $inn = if($T -contains $m){$m}else{'other'} };",
  "if ($e -is [System.ComponentModel.Win32Exception]) { $nat = [string][int]$e.NativeErrorCode } elseif ($e.InnerException -is [System.ComponentModel.Win32Exception]) { $nat = [string][int]$e.InnerException.NativeErrorCode }; MqRecord; if ($st -eq 'launch') { exit 91 } else { exit 90 } }",
].join(' ');
const PS_PROBE_RE = new RegExp('^MQPROBE stage=(prep|cred|launch|wait|exit) type=(' + PS_TYPES.join('|') + '|other|none) id=(' + PS_IDS.join('|') + '|other|none) inner=(' + PS_TYPES.join('|') + '|other|none) native=(\\d{1,10}|none) code=(-?\\d{1,10}|none) admin=(yes|no) bits=(32|64) seclogon=(running|stopped|other|missing) start=(disabled|manual|automatic|other|none) node=(yes|no) work=(yes|no) file=(yes|no)$');
function probeDiag(r) { const hits = String((r && r.stdout) ?? '').split(/\r?\n/).map((l) => l.trim()).filter((l) => l.startsWith('MQPROBE')); const [h0, h1] = hits; return h0 !== undefined && h1 === undefined && PS_PROBE_RE.test(h0) ? h0.slice(8) : 'not available (no single well-formed record)'; }
const PS_ADD_CODES = { 10: 'ACCOUNT_EXISTS_EXCEPTION', 11: 'PASSWORD_REJECTED_EXCEPTION', 12: 'ACCESS_DENIED_EXCEPTION', 13: 'OTHER_EXCEPTION' };
const psAddCreated = (r) => netRan(r) && r.status === 0;
function summarizeAdd(r) {
  const err = r && r.error ? (['ENOENT', 'EACCES', 'EPERM', 'ETIMEDOUT'].includes(r.error.code) ? r.error.code : 'OTHER') : 'none';
  const st = r && Number.isInteger(r.status) ? String(r.status) : 'null'; const sg = r && r.signal ? (['SIGTERM', 'SIGKILL'].includes(r.signal) ? r.signal : 'OTHER') : 'none';
  return 'spawn error=' + err + '; exit status=' + st + '; signal=' + sg + '; known result=' + (netRan(r) ? (r.status === 0 ? 'CREATED' : PS_ADD_CODES[r.status] || 'NONE_RECOGNISED') : 'NOT_FINISHED');
}
// Where the bare name "net" resolves, from where.exe's first line compared with the system folder; the path itself is never shown.
function netLocation(whereResult, sysRoot) {
  if (!whereResult || whereResult.error || whereResult.status !== 0) return 'not found or lookup failed';
  const first = String(whereResult.stdout ?? '').split(/\r?\n/).map((x) => x.trim()).find(Boolean); if (!first) return 'not found or lookup failed';
  return first.toLowerCase() === (String(sysRoot).replace(/[\\/]+$/, '') + '\\System32\\net.exe').toLowerCase() ? 'System32 net.exe' : 'a different location';
}
const STAT_OK = /^((postgres|initdb):(unresolved|stat=(ENOENT|EACCES|EPERM|EBUSY|ENOTDIR|EISDIR|EMFILE|OTHER)|exists=yes,nonzero=(yes|no),r=[yn],w=[yn],x=[yn]))(;(postgres|initdb):(unresolved|stat=(ENOENT|EACCES|EPERM|EBUSY|ENOTDIR|EISDIR|EMFILE|OTHER)|exists=yes,nonzero=(yes|no),r=[yn],w=[yn],x=[yn]))?$|^package:unresolved$/;
const STAT_PROBE = String.raw`import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL } from 'node:url';
const C = ['ENOENT', 'EACCES', 'EPERM', 'EBUSY', 'ENOTDIR', 'EISDIR', 'EMFILE']; const code = (e) => (e && C.includes(e.code) ? e.code : 'OTHER'); const o = [];
try {
  const dir = path.join(process.env.MQ_ROOT, 'node_modules', '@embedded-postgres', 'windows-x64'); const pj = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
  if (typeof pj.exports !== 'string') throw new Error('x'); const m = await import(pathToFileURL(path.resolve(dir, pj.exports)).href);
  for (const n of ['postgres', 'initdb']) { const p = m[n]; if (typeof p !== 'string') { o.push(n + ':unresolved'); continue; }
    try { const s = fs.statSync(p); o.push(n + ':exists=yes,nonzero=' + (s.size > 0 ? 'yes' : 'no') + ',r=' + ((s.mode & 0o444) === 0o444 ? 'y' : 'n') + ',w=' + ((s.mode & 0o222) ? 'y' : 'n') + ',x=' + ((s.mode & 0o111) === 0o111 ? 'y' : 'n')); } catch (e) { o.push(n + ':stat=' + code(e)); } }
} catch { o.length = 0; o.push('package:unresolved'); }
fs.writeFileSync(process.env.MQ_STATOUT, o.join(';'));
`;
// SHAPE-END
// PSENV-START
// The child PowerShell gets the parent's environment except the module path, which is reset to the Windows PowerShell system folder; any other-case spelling of the variable is dropped first.
const psExe = (sysRoot) => path.join(sysRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
const psChildEnv = (sysRoot, parentEnv, extra) => ({ ...Object.fromEntries(Object.entries(parentEnv).filter(([k]) => k.toLowerCase() !== 'psmodulepath')), PSModulePath: path.join(sysRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'Modules'), ...extra });
const parentHasPs7Path = (parentEnv) => Object.entries(parentEnv).some(([k, v]) => k.toLowerCase() === 'psmodulepath' && /[\\/]PowerShell[\\/]7[\\/]/i.test(String(v)));
// PSENV-END
// Fixed facts only when the launcher printed nothing recognised: sizes, whether the token-scoped launcher processes exist (unknown if the query itself failed), whether the port answered (a web answer is NOT proof of success or ownership).
const PHASE_OK = /^(imports|folder|protect|secrets|database|database-initialise|database-start|database-setup|migrate|app-start|running)$/;
const lastPhase = () => { try { const v = fs.readFileSync(phaseFile, 'utf8').trim(); return PHASE_OK.test(v) ? v : 'invalid'; } catch { return 'not recorded'; } };
// Read-only observation of the two vendor binaries under the same basic-user token (no chmod, no open, no read of contents). The paths come from the installed package's own exports.
async function vendorStat() {
  if (process.arch !== 'x64') return 'not checked (unsupported architecture)';
  const pf = path.join(TMP, 'mqproof-statprobe-' + TOKEN + '.mjs'); const cf = path.join(TMP, 'mqproof-statprobe-' + TOKEN + '.cmd'); const of = path.join(TMP, 'mqproof-statout-' + TOKEN + '.txt');
  try {
    fs.rmSync(of, { force: true }); fs.writeFileSync(pf, STAT_PROBE, 'utf8');
    fs.writeFileSync(cf, '@echo off\r\nset MQ_ROOT=' + root + '\r\nset MQ_STATOUT=' + of + '\r\n"' + process.execPath + '" "' + pf + '"\r\n', 'ascii');
    const ru = run('runas', ['/trustlevel:0x20000', cf]); if (ru.status !== 0) return 'not observed (probe did not start)';
    let v = ''; const t = Date.now(); while (Date.now() - t < 30000 && !v) { await sleep(500); try { v = fs.readFileSync(of, 'utf8'); } catch { v = ''; } }
    return !v ? 'not observed (no answer in 30 s)' : STAT_OK.test(v) ? v : 'invalid';
  } catch { return 'not observed (probe error)'; } finally { for (const f of [pf, cf, of]) fs.rmSync(f, { force: true }); }
}
// Same read-only resolution as the stat probe, from the package's own exports; null when anything is not a plain string.
async function resolveVendorPaths() {
  try { const dir = path.join(root, 'node_modules', '@embedded-postgres', 'windows-x64'); const pj = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')); if (typeof pj.exports !== 'string') return null;
    const m = await import(toUrl(path.resolve(dir, pj.exports))); return typeof m.postgres === 'string' && typeof m.initdb === 'string' ? { postgres: m.postgres, initdb: m.initdb } : null; } catch { return null; }
}
async function recordFailureFacts(t) {
  const step = async (name, f) => { try { fact(name, await f()); } catch { fact(name, 'UNKNOWN (record failed)'); } };
  await step('first start: output shape', () => classifyShape(t));
  await step('first start: file named in output', async () => fileLabel(t, await resolveVendorPaths()));
  await step('first start: last phase', () => 'last phase reached: ' + lastPhase());
  await step('first start: liveness', async () => { const pr = mine(); const alive = pr === null ? 'unknown' : pr.length ? 'yes' : 'no'; const code = await get('http://127.0.0.1:3911/healthz'); return 'launcher processes alive: ' + alive + '; web port answered: ' + (code ? 'yes' : 'no'); });
  await step('first start: vendor files stat', () => vendorStat());
}
async function start(label) {
  fs.rmSync(outFile, { force: true }); fs.rmSync(tokFile, { force: true }); fs.rmSync(phaseFile, { force: true });
  fs.writeFileSync(psFile, "$id=[Security.Principal.WindowsIdentity]::GetCurrent(); $p=New-Object Security.Principal.WindowsPrincipal($id); \"admin=$($p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) samesid=$($id.User.Value -eq $env:MQ_ME)\" | Set-Content -Encoding ascii $env:MQ_TOKFILE\r\n", 'ascii');
  fs.writeFileSync(cmdFile, `@echo off\r\nset MQ_ME=${me}\r\nset MQ_TOKFILE=${tokFile}\r\n"${PS}" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "${psFile}"\r\ncd /d "${root}"\r\nset MARQUEE_DATA=${data}\r\nset PORT=3911\r\nset PGPORT=54911\r\nset MQ_PHASE_FILE=${phaseFile}\r\n"${process.execPath}" scripts\\local.mjs > "${outFile}" 2>&1\r\n`, 'ascii');
  const ru = run('runas', ['/trustlevel:0x20000', cmdFile]); if (ru.status !== 0) { check(label + ': launcher started', false, 'runas exit ' + ru.status); return false; }
  // The claim "restricted launcher" is observed from inside that launcher, not inferred from PostgreSQL starting.
  let tk = ''; const tt = Date.now(); while (Date.now() - tt < 60000 && !/admin=\w+ samesid=\w+/.test(tk)) { await sleep(500); try { tk = fs.readFileSync(tokFile, 'utf8'); } catch { tk = ''; } }
  const adm = /admin=(\w+)/.exec(tk)?.[1]; const same = /samesid=(\w+)/.exec(tk)?.[1];
  const restricted = adm === 'False' && same === 'True'; check(label + ': launcher token observed (not administrator, same account)', restricted, `administrator role ${adm ?? 'not observed'}, same account SID ${same ?? 'not observed'}`);
  if (!restricted) { stop(); return false; }
  const t0 = Date.now(); log = '';
  while (Date.now() - t0 < 240000) { try { log = fs.readFileSync(outFile, 'utf8'); } catch { log = ''; } if (/MarqueePro is running/.test(log) || /MarqueePro cannot start|MarqueePro stopped|Cannot protect|will not start/.test(log)) break; await sleep(1000); }
  const up = /MarqueePro is running/.test(log); const fl = up ? '' : fixedLines(log); check(label + ': launcher started', up, up ? '' : (fl || 'no recognised launcher message')); if (!up && !fl) await recordFailureFacts(log); return up;
}
function stop() { for (const pid of mine() || []) run('taskkill', ['/PID', pid, '/T', '/F']); }
let aliasNote = '';
function aliasesOrNone() { try { const r = localAccountAliases(); aliasNote = Object.keys(r).length ? '' : 'alias lookup returned no accounts'; return r; } catch (e) { aliasNote = String(e && e.message).replace(/[^\x20-\x7e]/g, '').slice(0, 80); return {}; } }
function aclCheck(label, target, tree) {
  const out = path.join(base, 'acl-' + Math.random().toString(16).slice(2) + '.txt'); const r = run(ICACLS, [target, '/save', out, ...(tree ? ['/T', '/C'] : [])]);
  if (r.status !== 0 || !fs.existsSync(out)) return check(label, false, 'icacls failed ' + (r.stderr || r.stdout));
  const txt = fs.readFileSync(out, 'utf16le').includes('D:') ? fs.readFileSync(out, 'utf16le') : fs.readFileSync(out, 'utf8'); const lines = txt.split(/\r?\n/).filter((l) => /^D:/.test(l));
  const bad = lines.flatMap((l) => sddlUnexpectedSids(l, allowed, aliasesOrNone()));
  check(label, lines.length > 0 && bad.length === 0, `${lines.length} entries read, unexpected trustees: ${[...new Set(bad)].join(' ') || 'none'}${aliasNote ? ' (' + aliasNote + ')' : ''}`); if (tree) check(label + ' (covers many entries)', lines.length >= 20, lines.length);
}
async function stateChecks(tag) {
  aclCheck(tag + ': data folder', data, false); aclCheck(tag + ': local-secrets.json', path.join(data, 'local-secrets.json'), false); aclCheck(tag + ': database folder, every entry', path.join(data, 'pg'), true);
  check(tag + ': web answers', (await get('http://127.0.0.1:3911/')) === 200);
}
try {
  if (await start('first start')) {
    await stateChecks('first start');
    // key file: created through the real sealing code with DATA_DIR on this folder
    const sealer = run(process.execPath, ['-e', `import(${JSON.stringify(toUrl(path.join(root, 'dist/src/integrations.js')))}).then(m=>{const s=m.seal({x:1},'a');console.log(s.length>10?'sealed':'no')})`], { env: { ...process.env, DATA_DIR: data, NODE_ENV: 'production' } });
    check('integration key file created by real code', /sealed/.test(sealer.stdout) && fs.existsSync(path.join(data, 'integration.key')), 'exit ' + sealer.status);
    aclCheck('integration.key', path.join(data, 'integration.key'), false);
    // a second local account must be refused. Exit 3 means EACCES/EPERM only; any other failure is exit 4 and fails the check, and the target must exist.
    const exists = (await Promise.resolve([path.join(data, 'local-secrets.json'), path.join(data, 'integration.key'), path.join(data, 'bootstrap-admin.txt')])).map((f) => [f, fs.existsSync(f)]);
    for (const [f, ok] of exists) check('target exists: ' + path.basename(f), ok);
    aclCheck('bootstrap-admin.txt', path.join(data, 'bootstrap-admin.txt'), false);
    const wr = run(path.join(sys, 'System32', 'where.exe'), ['net']); fact('second account: where net resolves', netLocation(wr, sys)); fact('second account: password longer than 14 characters', PW.length > 14 ? 'yes' : 'no');
    fact('second account: parent environment has a PowerShell 7 module path', parentHasPs7Path(process.env) ? 'yes' : 'no'); const pre = run('net', ['user', PROBE]); const absent = netProvesAbsent(pre); check('probe account name unused before this run', absent, absent ? 'lookup finished with the account-not-found message' : 'not proven, nothing was created or deleted'); fact('second account: lookup before add', summarizeNet(pre));
    if (absent) {
      const add = run(psExe(sys), ['-NoProfile', '-NonInteractive', '-Command', PS_ADD], { timeout: 60000, env: psChildEnv(sys, process.env, { MQ_USER: PROBE, MQ_PW: PW }) }); created = psAddCreated(add); ownedAccount = created; check('second local account created', created, 'exit ' + add.status); fact('second account: add (New-LocalUser)', summarizeAdd(add)); fact('second account: add diagnostic', psDiag(add));
      if (!created) { const post = run('net', ['user', PROBE]); fact('second account: lookup after the failed add', summarizeNet(post)); const unknownAdd = !netRan(add) || add.status === 13; /* 10, 11, 12 and any other finished status mean this call did not create it */ ownedAccount = unknownAdd && netProvesPresent(post); fact('second account: ownership', ownedAccount ? 'the name was proven free just before and exists now: created by this proof' : 'not established: no delete will be attempted'); }
      if (created) {
        fs.writeFileSync(path.join(base, 'control.txt'), 'readable control\n');
        fs.writeFileSync(path.join(base, 'probe.js'), "const fs=require('fs');try{if(process.argv[3]==='dir')fs.readdirSync(process.argv[2]);else fs.readFileSync(process.argv[2]);process.exit(0)}catch(e){process.exit(e.code==='EACCES'||e.code==='EPERM'?3:4)}\n");
        const asProbe = (file, mode = 'file', label = 'probe') => { const r = run(psExe(sys), ['-NoProfile', '-NonInteractive', '-Command', PS_PROBE], { timeout: 120000, env: psChildEnv(sys, process.env, { MQ_PW: PW, MQ_USER: PROBE, MQ_NODE: process.execPath, MQ_PROBE: path.join(base, 'probe.js'), MQ_FILE: file, MQ_MODE: mode, MQ_DIR: base }) }); fact('credential launch: ' + label, probeDiag(r)); return r; };
        const ctl = asProbe(path.join(base, 'control.txt'), 'file', 'control file'); check('control file readable by the second account', ctl.status === 0, 'exit ' + ctl.status);
        for (const f of ['local-secrets.json', 'integration.key', 'bootstrap-admin.txt']) { const r = asProbe(path.join(data, f), 'file', f); check(f + ' refused to the second account (EACCES/EPERM)', r.status === 3, 'exit ' + r.status); }
        const dd = asProbe(data, 'dir', 'data folder'); check('data folder listing refused to the second account (EACCES/EPERM)', dd.status === 3, 'exit ' + dd.status); const pd = asProbe(path.join(data, 'pg'), 'dir', 'database folder'); check('database folder listing refused to the second account (EACCES/EPERM)', pd.status === 3, 'exit ' + pd.status);
        const d = asProbe(path.join(data, 'pg', 'PG_VERSION'), 'file', 'database file'); check('database folder file refused to the second account (EACCES/EPERM)', d.status === 3, 'exit ' + d.status);
      }
    }
    stop(); await sleep(5000);
    if (await start('restart')) { await stateChecks('restart'); }
    stop(); await sleep(5000);
    // empty password file while a database exists: must refuse and must not reset it
    const sf = path.join(data, 'local-secrets.json'); const keep = fs.readFileSync(sf, 'utf8'); fs.writeFileSync(sf, '');
    const t = spawnSync(process.execPath, ['scripts/local.mjs'], { cwd: root, encoding: 'utf8', timeout: 120000, env: { ...process.env, MARQUEE_DATA: data, PORT: '3911', PGPORT: '54911' } });
    check('empty password file with a database: start refused', t.status !== 0 && /NOT reset/.test(t.stdout + t.stderr), `exit ${t.status}`); check('empty password file left empty (not reset)', fs.readFileSync(sf, 'utf8') === '');
    fs.writeFileSync(sf, keep);
  }
} catch (e) { check('script error', false, e.message || e); } finally { stop(); if (ownedAccount) { const del = run('net', ['user', PROBE, '/delete']); fact('second account: cleanup delete', (created ? 'account was created; ' : 'account proven created by this proof; ') + summarizeNet(del)); if (del.status !== 0) console.log('WARNING: could not delete the temporary account; the runner is discarded after the job.'); } }
fs.writeFileSync('win-proof-result.json', JSON.stringify({ when: new Date().toISOString(), node: process.version, os: process.env.OS, facts, note: 'Hosted runner accounts are administrators: this proof does not claim protection from administrators.', results }, null, 2));
process.exit(results.every((r) => r.ok) ? 0 : 1);
